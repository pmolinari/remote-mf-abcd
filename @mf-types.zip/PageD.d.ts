export * from './compiled-types/pages/PageD/index';
export { default } from './compiled-types/pages/PageD/index';