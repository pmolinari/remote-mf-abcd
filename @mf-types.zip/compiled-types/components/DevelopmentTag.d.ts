declare const DevelopmentTag: ({ position, children }: any) => import("react/jsx-runtime").JSX.Element;
export default DevelopmentTag;
