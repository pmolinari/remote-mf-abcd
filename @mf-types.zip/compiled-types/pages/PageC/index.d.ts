declare const PageC: () => import("react/jsx-runtime").JSX.Element;
export default PageC;
