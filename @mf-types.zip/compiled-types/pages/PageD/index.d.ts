declare const PageD: () => import("react/jsx-runtime").JSX.Element;
export default PageD;
