declare const PageB: () => import("react/jsx-runtime").JSX.Element;
export default PageB;
