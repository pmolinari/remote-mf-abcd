declare const PageA: () => import("react/jsx-runtime").JSX.Element;
export default PageA;
