declare function Router({ idModule }: {
    idModule?: string | undefined;
}): import("react/jsx-runtime").JSX.Element;
export default Router;
